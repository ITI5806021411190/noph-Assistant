// ==========================================
// ส่วนตั้งค่าเริ่มต้น (Configuration)
// ==========================================
const SPREADSHEET_ID = '1CjlIsoHlwug9Bfp-sNLfxVsKaMbC5DJdGxMWCBxW8wc';
const SHEET_NAME = 'Schedules';
const SHEET_USERS = 'Users';
const SHEET_RESOURCES = 'Resources'; 
const SHEET_REPORTS = 'DailyReports';
const SHEET_NOTIFICATIONS = 'Notifications';
const SHEET_SETTINGS = 'Settings';
const SHEET_AUDIT = 'AuditLogs';
const SHEET_ATTACHMENTS = 'Attachments';
const SHEET_RECURRING = 'RecurringRules';
const FALLBACK_BOT_TOKEN = '8432145540:AAFzSNx2E3E_2Jt2FSSzOeBThoFfpj-Vec4'; // ตั้งค่าจริงใน Script Properties: BOT_TOKEN
const FALLBACK_GEMINI_API_KEY = 'AIzaSyCTAGEJh6R-JOSDH20062c1NEeFHix_XW8'; // ตั้งค่าจริงใน Script Properties: GEMINI_API_KEY
const FALLBACK_VERCEL_API_SECRET = 'HAOS_1777448392812_5f154d07d5ca59a27854741941470dc3'; // ตั้งค่าเดียวกันใน Vercel env: GAS_API_SECRET และ Script Properties: VERCEL_API_SECRET

function getScriptProp_(key, fallbackValue) {
  var value = PropertiesService.getScriptProperties().getProperty(key);
  return value || fallbackValue || '';
}

function getGeminiApiKey_() {
  return getScriptProp_('GEMINI_API_KEY', FALLBACK_GEMINI_API_KEY);
}

function getTelegramBotToken_() {
  return getScriptProp_('BOT_TOKEN', FALLBACK_BOT_TOKEN);
}

function setSystemSecretsOnce() {
  return 'ไปที่ Project Settings > Script properties แล้วเพิ่ม GEMINI_API_KEY และ BOT_TOKEN';
}

function getDB() {
  return SpreadsheetApp.openById(SPREADSHEET_ID);
}

function getWebAppUrl() {
  return ScriptApp.getService().getUrl();
}

// ==========================================
// ระบบกลาง: Sheet Utilities / Audit / System Health
// ==========================================
function getOrCreateSheet_(name, headers, color) {
  var ss = getDB();
  var sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  ensureHeaders_(sheet, headers, color || '#e8f0fe');
  return sheet;
}

function ensureHeaders_(sheet, headers, color) {
  if (!sheet) return;
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var existing = sheet.getRange(1, 1, 1, lastCol).getValues()[0].map(function(v){ return String(v || '').trim(); });
  if (sheet.getLastRow() === 0 || existing.filter(String).length === 0) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
  } else {
    headers.forEach(function(h) {
      if (existing.indexOf(h) === -1) {
        sheet.getRange(1, sheet.getLastColumn() + 1).setValue(h);
        existing.push(h);
      }
    });
  }
  sheet.getRange(1, 1, 1, sheet.getLastColumn()).setFontWeight('bold').setBackground(color || '#e8f0fe');
  sheet.setFrozenRows(1);
}

function getColumnIndex_(sheet, headerName) {
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  for (var i = 0; i < headers.length; i++) {
    if (String(headers[i]).trim() === headerName) return i + 1;
  }
  return -1;
}

function getAuditSheet_() {
  return getOrCreateSheet_(SHEET_AUDIT, [
    'Audit ID', 'Timestamp', 'Actor Phone', 'Actor Name', 'Action', 'Entity Type', 'Entity ID', 'Summary', 'Before JSON', 'After JSON'
  ], '#dbeafe');
}

function logAudit_(actorPhone, actorName, action, entityType, entityId, summary, beforeObj, afterObj) {
  try {
    var sheet = getAuditSheet_();
    sheet.appendRow([
      'AUD-' + Utilities.getUuid().substring(0, 8),
      new Date(),
      actorPhone ? "'" + actorPhone.toString().replace(/'/g, '') : '',
      actorName || '',
      action || '',
      entityType || '',
      entityId || '',
      summary || '',
      beforeObj ? JSON.stringify(beforeObj) : '',
      afterObj ? JSON.stringify(afterObj) : ''
    ]);
  } catch (e) {
    Logger.log('Audit log failed: ' + e.toString());
  }
}

function getSettingsSheet_() {
  var sheet = getOrCreateSheet_(SHEET_SETTINGS, ['Key', 'Value', 'Description', 'Updated At'], '#fef3c7');
  if (sheet.getLastRow() <= 1) {
    sheet.appendRow(['SYSTEM_STATUS', 'ON', 'สถานะการแจ้งเตือน/ระบบอัตโนมัติ', new Date()]);
    sheet.appendRow(['PUBLIC_LINK_EXPIRY_DAYS', '0', '0 = ไม่หมดอายุ', new Date()]);
  }
  return sheet;
}

function getSetting_(key, fallbackValue) {
  try {
    var sheet = getSettingsSheet_();
    var data = sheet.getDataRange().getValues();
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][0]) === key) return data[i][1] || fallbackValue;
    }
  } catch(e) {}
  return fallbackValue;
}

function setSetting_(key, value, description) {
  var sheet = getSettingsSheet_();
  var data = sheet.getDataRange().getValues();
  for (var i = 1; i < data.length; i++) {
    if (String(data[i][0]) === key) {
      sheet.getRange(i + 1, 2).setValue(value);
      if (description) sheet.getRange(i + 1, 3).setValue(description);
      sheet.getRange(i + 1, 4).setValue(new Date());
      return;
    }
  }
  sheet.appendRow([key, value, description || '', new Date()]);
}

function getSystemHealth() {
  try {
    var ss = getDB();
    var checks = [];
    var requiredSheets = [SHEET_NAME, SHEET_USERS, SHEET_RESOURCES, SHEET_REPORTS, SHEET_NOTIFICATIONS, SHEET_SETTINGS, SHEET_AUDIT];
    requiredSheets.forEach(function(name) {
      var sh = ss.getSheetByName(name);
      checks.push({ name: 'ชีต ' + name, ok: !!sh, detail: sh ? (sh.getLastRow() - 1) + ' records' : 'ไม่พบชีต' });
    });
    checks.push({ name: 'Gemini API Key', ok: !!getGeminiApiKey_(), detail: getGeminiApiKey_() ? 'พร้อมใช้งาน' : 'ยังไม่ได้ตั้งค่า' });
    checks.push({ name: 'Telegram Bot Token', ok: !!getTelegramBotToken_(), detail: getTelegramBotToken_() ? 'พร้อมใช้งาน' : 'ยังไม่ได้ตั้งค่า' });
    checks.push({ name: 'Web App URL', ok: !!getWebAppUrl(), detail: getWebAppUrl() || 'ยังไม่ได้ deploy' });
    var allOk = checks.every(function(c){ return c.ok; });
    return { success: true, allOk: allOk, checks: checks, systemStatus: getSetting_('SYSTEM_STATUS', 'ON') };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}

function getAuditLogs(limit) {
  try {
    var sheet = getAuditSheet_();
    var data = sheet.getDataRange().getValues();
    var result = [];
    var max = limit || 80;
    for (var i = data.length - 1; i >= 1 && result.length < max; i--) {
      result.push({
        id: data[i][0],
        time: data[i][1] instanceof Date ? Utilities.formatDate(data[i][1], 'GMT+7', 'dd/MM/yyyy HH:mm:ss') : data[i][1],
        actorPhone: String(data[i][2] || '').replace(/'/g, ''),
        actorName: data[i][3],
        action: data[i][4],
        entityType: data[i][5],
        entityId: data[i][6],
        summary: data[i][7]
      });
    }
    return { success: true, data: result };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}

// 9) ปรับ doGet(e) รองรับ Public Link
function doGet(e) {
  if (e && e.parameter && e.parameter.publicId) {
    var template = HtmlService.createTemplateFromFile('PublicSchedule');
    template.publicId = e.parameter.publicId;
    return template
      .evaluate()
      .setTitle('Public Schedule - Health Assistant OS')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
      .addMetaTag('viewport', 'width=device-width, initial-scale=1');
  }
  
  return HtmlService.createHtmlOutputFromFile('Index')
    .setTitle('Health Assistant OS - Nakhon Nayok PHO')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

// ==========================================
// ฟังก์ชัน Setup สร้างฐานข้อมูล
// ==========================================
function Setup() {
  var ss = getDB();
  
  var sheetSchedules = ss.getSheetByName(SHEET_NAME);
  if (!sheetSchedules) {
    sheetSchedules = ss.insertSheet(SHEET_NAME);
  }
  var headersSchedules = [
    "ID", "Event Name", "Start Time", "End Time", "Meeting Link", 
    "Visibility", "User Email", "Telegram Chat ID", "Notify Lead Time", 
    "Status", "Owner Phone", "Resource ID", "Approval Status", "Approver Phone", "File URL", "Details", "Location"
  ];
  sheetSchedules.getRange(1, 1, 1, headersSchedules.length).setValues([headersSchedules]);
  sheetSchedules.getRange(1, 1, 1, headersSchedules.length).setFontWeight("bold").setBackground("#e8f0fe");
  sheetSchedules.getRange("K:K").setNumberFormat('@'); 
  sheetSchedules.getRange("N:N").setNumberFormat('@'); 
  sheetSchedules.setFrozenRows(1);
  ensureHeaders_(sheetSchedules, headersSchedules.concat(["Public Enabled", "Public Expires At", "Public Created At"]), "#e8f0fe");

  var sheetUsers = ss.getSheetByName(SHEET_USERS);
  if (!sheetUsers) {
    sheetUsers = ss.insertSheet(SHEET_USERS);
  }
  var headersUsers = [
    "Phone (Username)", "PIN (Password)", "Full Name", "Position", "Department", "Email", "PDPA Status", "Role", "Timestamp", "Email Notify", "Account Status", "Last Login"
  ];
  ensureHeaders_(sheetUsers, headersUsers, '#d4edda');
  sheetUsers.getRange("A:B").setNumberFormat('@');
  sheetUsers.setFrozenRows(1);
  
  var sheetRes = ss.getSheetByName(SHEET_RESOURCES);
  if (!sheetRes) {
    sheetRes = ss.insertSheet(SHEET_RESOURCES);
    var resHeaders = ["Resource ID", "Resource Name", "Type"];
    sheetRes.getRange(1, 1, 1, resHeaders.length).setValues([resHeaders]);
    sheetRes.appendRow(["ROOM01", "ห้องประชุมชั้น 2", "Room"]);
    sheetRes.appendRow(["ZOOM01", "Zoom Account 1 (กลาง)", "Online"]);
  }

  var sheetReports = ss.getSheetByName(SHEET_REPORTS);
  if (!sheetReports) {
    sheetReports = ss.insertSheet(SHEET_REPORTS);
  }
  var headersReports = [
    "Report ID", "Date", "Time", "User Phone", "User Name", "Department", "Leave Type", "Work Details", "Remarks", "File URL", "Timestamp"
  ];
  sheetReports.getRange(1, 1, 1, headersReports.length).setValues([headersReports]);
  sheetReports.getRange(1, 1, 1, headersReports.length).setFontWeight("bold").setBackground("#fff3cd");
  sheetReports.getRange("D:D").setNumberFormat('@'); 
  sheetReports.setFrozenRows(1);

  var sheetNotif = ss.getSheetByName(SHEET_NOTIFICATIONS);
  if (!sheetNotif) {
    sheetNotif = ss.insertSheet(SHEET_NOTIFICATIONS);
  }
  var headersNotif = ["Notif ID", "Target Phone", "Message", "Is Read", "Timestamp"];
  sheetNotif.getRange(1, 1, 1, headersNotif.length).setValues([headersNotif]);
  sheetNotif.getRange(1, 1, 1, headersNotif.length).setFontWeight("bold").setBackground("#f8d7da");
  sheetNotif.getRange("B:B").setNumberFormat('@'); 
  sheetNotif.setFrozenRows(1);

  getSettingsSheet_();
  getAuditSheet_();
  getOrCreateSheet_(SHEET_ATTACHMENTS, ['Attachment ID', 'Entity Type', 'Entity ID', 'File URL', 'File Name', 'Mime Type', 'Uploaded By', 'Timestamp'], '#ede9fe');
  getOrCreateSheet_(SHEET_RECURRING, ['Rule ID', 'Owner Phone', 'Owner Name', 'Event Name', 'Details', 'Location', 'Meeting Link', 'Resource ID', 'Lead Time', 'Work Status', 'Frequency', 'Interval', 'By Day', 'Start Date', 'End Date', 'Next Run', 'Active', 'Last Run', 'Created At'], '#dcfce7');
  getOrCreateSheet_('ApprovalHistory', ['History ID', 'Schedule ID', 'Action', 'Actor Phone', 'Reason', 'Timestamp'], '#fef3c7');

  var usersData = sheetUsers.getDataRange().getValues();
  var adminExists = false;
  for (var i = 1; i < usersData.length; i++) {
    if (usersData[i][0].toString() === "0868246621") { 
      adminExists = true; 
      break; 
    }
  }
  
  if (!adminExists) {
    sheetUsers.appendRow([
      "'0868246621", "'235689", "นายวรวงศ์ คูณหอม", "นักวิชาการคอมพิวเตอร์", 
      "99 กลุ่มงานสุขภาพดิจิทัล", "wongnazaipot@gmail.com", "Accepted", "Super Admin", new Date(), "On", "Active", new Date()
    ]);
  }
  return "Setup ระบบฐานข้อมูลเรียบร้อยครับ!";
}

// ==========================================
// อัปโหลดไฟล์
// ==========================================
function uploadFileToDrive(base64Data, fileName, mimeType) {
  try {
    var blob = Utilities.newBlob(Utilities.base64Decode(base64Data), mimeType, fileName);
    var folderIterator = DriveApp.getFoldersByName("HealthAssistant_Files");
    var folder;
    if (folderIterator.hasNext()) {
      folder = folderIterator.next();
    } else {
      folder = DriveApp.createFolder("HealthAssistant_Files");
    }
    var file = folder.createFile(blob);
    file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); 
    return { success: true, url: file.getUrl() };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}

// ==========================================
// ระบบผู้ใช้งาน & โปรไฟล์
// ==========================================
function loginAccount(phone, pin) {
  try {
    var sheetUsers = getDB().getSheetByName(SHEET_USERS);
    if (!sheetUsers) {
      return { success: false, message: "กรุณากด Setup ก่อนครับ" };
    }
    var usersData = sheetUsers.getDataRange().getValues();
    for (var i = 1; i < usersData.length; i++) {
      if (usersData[i][0].toString() === phone && usersData[i][1].toString() === pin) {
        var statusCol = getColumnIndex_(sheetUsers, 'Account Status');
        var lastLoginCol = getColumnIndex_(sheetUsers, 'Last Login');
        var accountStatus = statusCol > 0 ? (usersData[i][statusCol - 1] || 'Active') : 'Active';
        if (accountStatus === 'Inactive') {
          return { success: false, message: 'บัญชีนี้ถูกปิดใช้งาน กรุณาติดต่อผู้ดูแลระบบ' };
        }
        if (lastLoginCol > 0) sheetUsers.getRange(i + 1, lastLoginCol).setValue(new Date());
        logAudit_(phone, usersData[i][2], 'LOGIN', 'User', phone, 'เข้าสู่ระบบสำเร็จ', null, null);
        return { 
          success: true, 
          userData: { 
            phone: usersData[i][0].toString(), 
            fullName: usersData[i][2], 
            position: usersData[i][3], 
            department: usersData[i][4], 
            email: usersData[i][5], 
            role: usersData[i][7], 
            emailNotify: usersData[i][9] || "On",
            accountStatus: accountStatus
          } 
        };
      }

    }
    return { success: false, message: "ข้อมูลไม่ถูกต้อง" };
  } catch (error) { 
    return { success: false, message: error.message }; 
  }
}

function registerAccount(data) {
  try {
    if (data.phone.toString().length !== 10) {
      return { success: false, message: "กรุณากรอกเบอร์โทรศัพท์ 10 หลัก" };
    }
    var sheetUsers = getDB().getSheetByName(SHEET_USERS);
    var usersData = sheetUsers.getDataRange().getValues();
    for (var i = 1; i < usersData.length; i++) {
      if (usersData[i][0].toString() === data.phone.toString()) {
        return { success: false, message: "เบอร์นี้ลงทะเบียนไว้แล้ว" };
      }
    }
    var generatedPIN = Math.floor(100000 + Math.random() * 900000).toString();
    sheetUsers.appendRow([
      "'" + data.phone, "'" + generatedPIN, data.fullName, data.position, data.department, data.email, "Accepted", "User", new Date(), "On", "Active", ""
    ]);
    logAudit_(data.phone, data.fullName, 'REGISTER', 'User', data.phone, 'ลงทะเบียนผู้ใช้ใหม่', null, data);
    return { success: true, message: "ลงทะเบียนสำเร็จ! รหัส PIN ของคุณคือ: " + generatedPIN, pin: generatedPIN };
  } catch (error) { 
    return { success: false, message: error.message }; 
  }
}

function updateUserProfile(data) {
  try {
    var sheetUsers = getDB().getSheetByName(SHEET_USERS);
    var usersData = sheetUsers.getDataRange().getValues();
    for (var i = 1; i < usersData.length; i++) {
      if (usersData[i][0].toString() === data.phone.toString()) {
        sheetUsers.getRange(i + 1, 4).setValue(data.position);
        sheetUsers.getRange(i + 1, 5).setValue(data.department);
        sheetUsers.getRange(i + 1, 6).setValue(data.email);
        sheetUsers.getRange(i + 1, 10).setValue(data.emailNotify);
        return { success: true, message: "อัปเดตข้อมูลส่วนตัวเรียบร้อยแล้ว" };
      }
    }
    return { success: false, message: "ไม่พบบัญชีผู้ใช้งานนี้ในระบบ" };
  } catch (error) { 
    return { success: false, message: error.toString() }; 
  }
}

function getAllUsers() {
  try {
    var sheetUsers = getDB().getSheetByName(SHEET_USERS);
    var usersData = sheetUsers.getDataRange().getValues();
    var usersList = [];
    for (var i = 1; i < usersData.length; i++) {
      usersList.push({ 
        phone: usersData[i][0].toString(), 
        name: usersData[i][2], 
        position: usersData[i][3], 
        department: usersData[i][4] 
      });
    }
    return { success: true, data: usersList };
  } catch (error) { 
    return { success: false, message: error.toString() }; 
  }
}

// ==========================================
// การจัดการ Super Admin
// ==========================================
function getAdminUsersData() {
  try {
    var sheet = getDB().getSheetByName(SHEET_USERS);
    var data = sheet.getDataRange().getValues();
    var result = [];
    for (var i = 1; i < data.length; i++) {
      var rawPin = data[i][1].toString();
      if (rawPin.startsWith("'")) {
        rawPin = rawPin.substring(1);
      }
      result.push({ 
        phone: data[i][0].toString(), 
        pin: rawPin, 
        name: data[i][2], 
        position: data[i][3], 
        department: data[i][4], 
        email: data[i][5], 
        role: data[i][7],
        accountStatus: data[i][10] || 'Active',
        lastLogin: data[i][11] instanceof Date ? Utilities.formatDate(data[i][11], 'GMT+7', 'dd/MM/yyyy HH:mm') : (data[i][11] || '-')
      });
    }
    return { success: true, data: result };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

function adminAddNewUser(data) {
  try {
    if (data.phone.toString().length !== 10) {
      return { success: false, message: "เบอร์โทรศัพท์ต้องมี 10 หลัก" };
    }
    var sheet = getDB().getSheetByName(SHEET_USERS);
    var usersData = sheet.getDataRange().getValues();
    for (var i = 1; i < usersData.length; i++) {
      if (usersData[i][0].toString() === data.phone.toString()) {
        return { success: false, message: "เบอร์นี้มีในระบบแล้ว" };
      }
    }
    var generatedPIN = Math.floor(100000 + Math.random() * 900000).toString();
    sheet.appendRow([
      "'" + data.phone, "'" + generatedPIN, data.fullName, data.position, data.department, data.email, "Added by Admin", data.role, new Date(), "On", "Active", ""
    ]);
    logAudit_('', 'Admin', 'CREATE_USER', 'User', data.phone, 'เพิ่มผู้ใช้งานใหม่: ' + data.fullName, null, data);
    return { success: true, message: "เพิ่มสำเร็จ! รหัส PIN ของเขาคือ: " + generatedPIN };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

function updateUserRole(phone, newRole) {
  try {
    var sheet = getDB().getSheetByName(SHEET_USERS);
    var data = sheet.getDataRange().getValues();
    for (var i = 1; i < data.length; i++) {
      if (data[i][0].toString() === phone.toString()) {
        var beforeRole = data[i][7];
        sheet.getRange(i + 1, 8).setValue(newRole); 
        logAudit_('', 'Admin', 'UPDATE_ROLE', 'User', phone, 'เปลี่ยนสิทธิ์จาก ' + beforeRole + ' เป็น ' + newRole, {role: beforeRole}, {role: newRole});
        return { success: true, message: "อัปเดตสิทธิ์เรียบร้อย" };
      }
    }
    return { success: false, message: "ไม่พบผู้ใช้งาน" };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

function deleteUserAccount(phone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_USERS);
    var data = sheet.getDataRange().getValues();
    if (phone.toString() === "0868246621") {
      return { success: false, message: "ไม่อนุญาตให้ลบบัญชี Super Admin" };
    }
    for (var i = 1; i < data.length; i++) {
      if (data[i][0].toString() === phone.toString()) {
        var deleted = { phone: data[i][0], name: data[i][2], role: data[i][7] };
        sheet.deleteRow(i + 1); 
        logAudit_('', 'Admin', 'DELETE_USER', 'User', phone, 'ลบบัญชีผู้ใช้งาน: ' + deleted.name, deleted, null);
        return { success: true, message: "ลบเรียบร้อยแล้ว" };
      }
    }
    return { success: false, message: "ไม่พบผู้ใช้งาน" };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

function addResource(name, type) {
  try {
    var sheet = getDB().getSheetByName(SHEET_RESOURCES);
    var id = "RES-" + Utilities.getUuid().substring(0, 5).toUpperCase();
    sheet.appendRow([id, name, type]);
    logAudit_('', 'Admin', 'CREATE_RESOURCE', 'Resource', id, 'เพิ่มทรัพยากร: ' + name, null, {id:id, name:name, type:type});
    return { success: true, message: "เพิ่มทรัพยากรใหม่เรียบร้อย" };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

function deleteResource(id) {
  try {
    var sheet = getDB().getSheetByName(SHEET_RESOURCES);
    var data = sheet.getDataRange().getValues();
    for (var i = 1; i < data.length; i++) {
      if (data[i][0] === id) {
        var deleted = { id: data[i][0], name: data[i][1], type: data[i][2] };
        sheet.deleteRow(i + 1); 
        logAudit_('', 'Admin', 'DELETE_RESOURCE', 'Resource', id, 'ลบทรัพยากร: ' + deleted.name, deleted, null);
        return { success: true, message: "ลบทรัพยากรเรียบร้อย" };
      }
    }
    return { success: false, message: "ไม่พบทรัพยากร" };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

function getAvailableResources() {
  try {
    var sheet = getDB().getSheetByName(SHEET_RESOURCES);
    var data = sheet.getDataRange().getValues();
    var resources = [];
    for (var i = 1; i < data.length; i++) {
      resources.push({ id: data[i][0], name: data[i][1], type: data[i][2] });
    }
    return { success: true, data: resources };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

// ==========================================
// ระบบการแจ้งเตือน (Notifications)
// ==========================================
function getNotifications(phone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NOTIFICATIONS);
    if (!sheet) {
      return { success: true, data: [] };
    }
    var data = sheet.getDataRange().getValues();
    var notifs = [];
    var targetPhone = phone.toString().replace(/'/g, '');
    for (var i = 1; i < data.length; i++) {
      if (data[i][1].toString().replace(/'/g, '') === targetPhone && data[i][3] === false) {
        notifs.push({ 
          id: data[i][0], 
          message: data[i][2], 
          time: Utilities.formatDate(new Date(data[i][4]), "GMT+7", "dd/MM/yyyy HH:mm") 
        });
      }
    }
    return { success: true, data: notifs.reverse() };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

function markNotifAsRead(id) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NOTIFICATIONS);
    var data = sheet.getDataRange().getValues();
    for (var i = 1; i < data.length; i++) {
      if (data[i][0] === id) {
        sheet.getRange(i + 1, 4).setValue(true);
        return { success: true };
      }
    }
    return { success: false };
  } catch(e) { 
    return { success: false }; 
  }
}

// ==========================================
// ระบบรายงานประจำวัน (Daily Report)
// ==========================================
function saveDailyReport(data) {
  try {
    var sheet = getDB().getSheetByName(SHEET_REPORTS);
    if (!sheet) {
      Setup();
      sheet = getDB().getSheetByName(SHEET_REPORTS);
    }
    var timestamp = new Date();
    if (data.reportId) {
      var records = sheet.getDataRange().getValues();
      for (var i = 1; i < records.length; i++) {
        if (records[i][0] === data.reportId && records[i][3].toString().replace(/'/g, '') === data.userPhone.toString()) {
          sheet.getRange(i + 1, 3).setValue(data.time);
          sheet.getRange(i + 1, 7).setValue(data.leaveType);
          sheet.getRange(i + 1, 8).setValue(data.workDetails);
          sheet.getRange(i + 1, 9).setValue(data.remarks);
          if (data.fileUrl) sheet.getRange(i + 1, 10).setValue(data.fileUrl);
          sheet.getRange(i + 1, 11).setValue(timestamp);
          logAudit_(data.userPhone, data.userName, 'UPDATE_REPORT', 'DailyReport', data.reportId, 'อัปเดตรายงานประจำวัน', null, data);
          return { success: true, message: "อัปเดตรายงานเรียบร้อยแล้วครับ" };
        }
      }
      return { success: false, message: "ไม่พบรายงานที่ต้องการแก้ไข หรือคุณไม่มีสิทธิ์แก้ไข" };
    }
    var newId = "REP-" + Utilities.getUuid().substring(0, 8);
    sheet.appendRow([newId, data.date, data.time, "'" + data.userPhone, data.userName, data.department, data.leaveType, data.workDetails, data.remarks, data.fileUrl || "", timestamp]);
    logAudit_(data.userPhone, data.userName, 'CREATE_REPORT', 'DailyReport', newId, 'บันทึกรายงานประจำวัน', null, data);
    return { success: true, message: "บันทึกรายงานประจำวันเรียบร้อยครับ" };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

function deleteDailyReport(reportId, phone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_REPORTS);
    var data = sheet.getDataRange().getValues();
    var now = new Date();
    var targetPhone = phone.toString().replace(/'/g, '');
    for (var i = 1; i < data.length; i++) {
      if (data[i][0] === reportId && data[i][3].toString().replace(/'/g, '') === targetPhone) {
        var reportDate = new Date(data[i][1]);
        var diffDays = Math.floor((now - reportDate) / (1000 * 60 * 60 * 24));
        if (diffDays <= 7) {
          var deleted = { id: data[i][0], date: data[i][1], userPhone: data[i][3], details: data[i][7] };
          sheet.deleteRow(i + 1);
          logAudit_(phone, '', 'DELETE_REPORT', 'DailyReport', reportId, 'ลบรายงานประจำวัน', deleted, null);
          return { success: true, message: "ลบรายงานเรียบร้อยแล้ว" };
        } else {
          return { success: false, message: "ระบบไม่อนุญาตให้ลบข้อมูลย้อนหลังเกิน 7 วันครับ" };
        }
      }
    }
    return { success: false, message: "ไม่พบรายงานที่ต้องการลบ หรือคุณไม่มีสิทธิ์ลบ" };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

function getMyReports(phone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_REPORTS);
    if (!sheet) {
      return { success: true, data: [] };
    }
    var data = sheet.getDataRange().getValues();
    var reports = [];
    var targetPhone = phone.toString().replace(/'/g, ''); 
    for (var i = 1; i < data.length; i++) {
      var rowPhone = data[i][3].toString().replace(/'/g, '');
      if (rowPhone === targetPhone) {
        var d = data[i][1];
        var dateStr = (d instanceof Date) ? Utilities.formatDate(d, "GMT+7", "yyyy-MM-dd") : d;
        reports.push({
          id: data[i][0], 
          date: dateStr, 
          time: data[i][2],
          leaveType: data[i][6], 
          details: data[i][7], 
          remarks: data[i][8], 
          fileUrl: data[i][9]
        });
      }
    }
    return { success: true, data: reports.reverse() }; 
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

function getTeamReports(userDepartment, userRole) {
  try {
    var ss = getDB();
    var sheetUsers = ss.getSheetByName(SHEET_USERS);
    var sheetReports = ss.getSheetByName(SHEET_REPORTS);
    if (!sheetReports) {
      return { success: true, stats: [], reports: [], isHead: false };
    }
    
    var usersData = sheetUsers.getDataRange().getValues();
    var reportsData = sheetReports.getDataRange().getValues();
    var todayStr = Utilities.formatDate(new Date(), "GMT+7", "yyyy-MM-dd");
    var teamMembers = [];
    var fullReports = [];
    
    var cleanUserDept = userDepartment.replace(/[0-9\s]/g, ''); 
    for (var i = 1; i < usersData.length; i++) {
      if (usersData[i][4].toString().indexOf(cleanUserDept) !== -1 || usersData[i][4] === userDepartment) {
        teamMembers.push({ 
          phone: usersData[i][0].toString().replace(/'/g, ''), 
          name: usersData[i][2], 
          submittedToday: false 
        });
      }
    }

    for (var j = 1; j < reportsData.length; j++) {
      var repDept = reportsData[j][5].toString();
      if (repDept.indexOf(cleanUserDept) !== -1 || repDept === userDepartment) {
        var d = reportsData[j][1];
        var repDateStr = (d instanceof Date) ? Utilities.formatDate(d, "GMT+7", "yyyy-MM-dd") : d;
        if (userRole === 'Head' || userRole === 'Super Admin') {
          fullReports.push({
            id: reportsData[j][0], 
            name: reportsData[j][4], 
            date: repDateStr, 
            time: reportsData[j][2],
            leaveType: reportsData[j][6], 
            details: reportsData[j][7], 
            remarks: reportsData[j][8], 
            fileUrl: reportsData[j][9]
          });
        }
        if (repDateStr === todayStr) {
          var repPhone = reportsData[j][3].toString().replace(/'/g, '');
          for (var k = 0; k < teamMembers.length; k++) {
            if (teamMembers[k].phone === repPhone) {
              teamMembers[k].submittedToday = true;
              teamMembers[k].leaveType = reportsData[j][6]; 
            }
          }
        }
      }
    }
    return { 
      success: true, 
      stats: teamMembers, 
      reports: fullReports.reverse(), 
      isHead: (userRole === 'Head' || userRole === 'Super Admin') 
    };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

// ==========================================
// ระบบ Schedules 
// ==========================================
// 6) ปรับฟังก์ชัน getUserSchedules เพิ่มการส่งค่าต่างๆ กลับ
function getUserSchedules(ownerPhone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NAME);
    if (!sheet) {
      return { success: true, data: [] };
    }
    var data = sheet.getDataRange().getValues();
    var result = [];
    var targetPhone = ownerPhone.toString().replace(/'/g, '');
    for (var i = 1; i < data.length; i++) {
      if (data[i][10].toString().replace(/'/g, '') === targetPhone) {
        
        // รูปแบบสำหรับ datetime-local input
        var rawStart = "";
        try {
          rawStart = Utilities.formatDate(new Date(data[i][2]), "GMT+7", "yyyy-MM-dd'T'HH:mm");
        } catch(e) {}

        result.push({ 
          id: data[i][0], 
          eventName: data[i][1], 
          startTime: Utilities.formatDate(new Date(data[i][2]), "GMT+7", "dd/MM/yyyy HH:mm"), 
          rawStartTime: rawStart,
          status: data[i][9], // คงไว้เพื่อไม่ให้กระทบส่วนเก่า
          workStatus: data[i][9] || "อยู่ระหว่างการดำเนินการ", // 5) ค่าสถานะงานจริงๆ
          approval: data[i][12], 
          fileUrl: data[i][14],
          details: data[i][15], 
          location: data[i][16], 
          meetingLink: data[i][4],
          resourceId: data[i][11],
          leadTime: data[i][8],
          approverPhone: data[i][13].toString().replace(/'/g, ''),
          chatId: data[i][7],
          publicId: data[i][0] // 9) สำหรับ Public Link
        });
      }
    }
    return { success: true, data: result.reverse() };
  } catch (e) { 
    return { success: false, message: e.toString() }; 
  }
}

function deleteSchedule(id, ownerPhone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NAME);
    var data = sheet.getDataRange().getValues();
    var targetPhone = ownerPhone.toString().replace(/'/g, '');
    for (var i = 1; i < data.length; i++) {
      if (data[i][0] === id && data[i][10].toString().replace(/'/g, '') === targetPhone) {
        var deleted = { id: data[i][0], eventName: data[i][1], ownerPhone: data[i][10] };
        sheet.deleteRow(i + 1); 
        logAudit_(ownerPhone, '', 'DELETE_SCHEDULE', 'Schedule', id, 'ลบตารางงาน: ' + deleted.eventName, deleted, null);
        return { success: true, message: "ลบสำเร็จ" };
      }
    }
    return { success: false, message: "ไม่พบข้อมูล" };
  } catch (e) { 
    return { success: false, message: e.toString() }; 
  }
}

function syncToGoogleCalendar(data) {
  try { 
    var desc = "รายละเอียด: " + (data.details || "-") + "\n\nสร้างผ่านระบบปฏิบัติการสาธารณสุข";
    var loc = data.location || data.meetingLink || "";
    return CalendarApp.getDefaultCalendar().createEvent(
      data.eventName, 
      new Date(data.startTime), 
      new Date(new Date(data.startTime).getTime() + 3600000), 
      { location: loc, description: desc }
    ).getId(); 
  } catch (e) { 
    return "Error"; 
  }
}

function saveScheduleV2(data) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NAME);
    var notifSheet = getDB().getSheetByName(SHEET_NOTIFICATIONS);
    if (!sheet || !notifSheet) { 
      Setup(); 
      sheet = getDB().getSheetByName(SHEET_NAME); 
      notifSheet = getDB().getSheetByName(SHEET_NOTIFICATIONS); 
    }
    
    var id = "APP-" + Utilities.getUuid().substring(0, 8);
    var calId = syncToGoogleCalendar(data);
    var approvalStatus = data.approverPhone ? "Pending" : "Approved";
    var assignees = data.assignees || [];
    assignees.push(data.ownerPhone);
    var uniquePhones = assignees.filter(function(item, pos) { 
      return assignees.indexOf(item) == pos; 
    });

    uniquePhones.forEach(function(phone, i) {
      var loopId = (i === 0) ? id : "APP-" + Utilities.getUuid().substring(0, 8);
      var finalEventName = (phone !== data.ownerPhone) ? "[รับมอบหมายจาก: " + data.ownerName + "] " + data.eventName : data.eventName;
      
      // 5) กำหนด Status ให้เป็น Work Status แทนคำว่า Pending
      var currentWorkStatus = data.workStatus || "อยู่ระหว่างการดำเนินการ";

      sheet.appendRow([
        loopId, finalEventName, data.startTime, data.startTime, data.meetingLink, 
        data.visibility, data.userEmail, data.chatId, data.leadTime, currentWorkStatus, 
        "'" + phone, data.resourceId || "", approvalStatus, "'" + (data.approverPhone || ""), 
        data.fileUrl || "", data.details || "", data.location || ""
      ]);

      if (phone !== data.ownerPhone) {
         var nId = "NTF-" + Utilities.getUuid().substring(0, 5);
         var nMsg = "มีงานใหม่ถูกมอบหมายให้คุณ: " + data.eventName + " (โดย: " + data.ownerName + ")";
         notifSheet.appendRow([nId, "'" + phone, nMsg, false, new Date()]);
      }
    });
    
    logAudit_(data.ownerPhone, data.ownerName, 'CREATE_SCHEDULE', 'Schedule', id, 'สร้างตารางงาน: ' + data.eventName, null, data);
    if (data.approverPhone) {
      notifyApprover(data.approverPhone, data.eventName, data.ownerName);
    }

    if (data.recurringEnabled) {
      saveRecurringRule({
        ownerPhone: data.ownerPhone,
        ownerName: data.ownerName,
        eventName: data.eventName,
        details: data.details || '',
        location: data.location || '',
        meetingLink: data.meetingLink || '',
        resourceId: data.resourceId || '',
        leadTime: data.leadTime || 15,
        workStatus: data.workStatus || 'อยู่ระหว่างการดำเนินการ',
        frequency: data.recurringFrequency || 'weekly',
        interval: data.recurringInterval || 1,
        byDay: data.recurringByDay || '',
        startDate: data.startTime,
        endDate: data.recurringEndDate || ''
      });
    }

    return { success: true, message: data.recurringEnabled ? "บันทึกกำหนดการและตั้งค่างานประจำสำเร็จ!" : "บันทึกกำหนดการสำเร็จ!" };
  } catch (e) { 
    return { success: false, message: e.toString() }; 
  }
}

// 4) เพิ่มฟังก์ชันอัปเดตตารางงาน (Update Schedule)
function updateScheduleV2(data) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NAME);
    var sheetData = sheet.getDataRange().getValues();
    var targetPhone = data.ownerPhone.toString().replace(/'/g, '');
    var now = new Date();

    for (var i = 1; i < sheetData.length; i++) {
      if (sheetData[i][0] === data.eventEditId && sheetData[i][10].toString().replace(/'/g, '') === targetPhone) {
        
        // ตรวจสอบเงื่อนไข 7 วัน อิงจากวันเริ่มงานเดิม
        var oldStartTime = new Date(sheetData[i][2]);
        var diffDays = Math.floor((now - oldStartTime) / (1000 * 60 * 60 * 24));
        
        if (diffDays > 7) {
          return { success: false, message: "ไม่อนุญาตให้แก้ไขข้อมูลย้อนหลังเกิน 7 วันครับ" };
        }

        // อัปเดตข้อมูล
        sheet.getRange(i + 1, 2).setValue(data.eventName);
        sheet.getRange(i + 1, 3).setValue(data.startTime);
        sheet.getRange(i + 1, 4).setValue(data.startTime); // ถือเป็น End Time เดียวกันชั่วคราว
        sheet.getRange(i + 1, 5).setValue(data.meetingLink || "");
        sheet.getRange(i + 1, 8).setValue(data.chatId || "");
        sheet.getRange(i + 1, 9).setValue(data.leadTime || 15);
        sheet.getRange(i + 1, 10).setValue(data.workStatus || "อยู่ระหว่างการดำเนินการ");
        sheet.getRange(i + 1, 12).setValue(data.resourceId || "");
        sheet.getRange(i + 1, 16).setValue(data.details || "");
        sheet.getRange(i + 1, 17).setValue(data.location || "");
        
        // ถ้ามีการอัปโหลดไฟล์ใหม่ ให้ทับของเดิม ถ้าไม่มี ให้ใช้ File URL เดิมต่อไป
        if (data.fileUrl && data.fileUrl !== "") {
          sheet.getRange(i + 1, 15).setValue(data.fileUrl);
        }

        logAudit_(data.ownerPhone, data.ownerName || '', 'UPDATE_SCHEDULE', 'Schedule', data.eventEditId, 'อัปเดตกำหนดการ: ' + data.eventName, null, data);
        return { success: true, message: "อัปเดตกำหนดการเรียบร้อยแล้วครับ" };
      }
    }
    return { success: false, message: "ไม่พบข้อมูลที่ต้องการแก้ไข หรือคุณไม่มีสิทธิ์แก้ไขงานนี้" };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

// 9) ฟังก์ชันดึงข้อมูลสำหรับ Public Link แบบปลอดภัย

function getPublicSchedule(publicId) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NAME);
    if (!sheet) return { success: false, message: "ระบบยังไม่ได้ตั้งค่า" };
    var data = sheet.getDataRange().getValues();
    var colPublicEnabled = getColumnIndex_(sheet, "Public Enabled");
    var colPublicExpiresAt = getColumnIndex_(sheet, "Public Expires At");
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][0]) === String(publicId)) {
        if (colPublicEnabled > 0) {
          var enabled = String(data[i][colPublicEnabled - 1] || '').toUpperCase();
          if (!(enabled === 'TRUE' || enabled === 'ON' || enabled === 'YES' || enabled === 'PUBLIC')) {
            return { success: false, message: "ลิงก์สาธารณะนี้ยังไม่ได้เปิดใช้งาน หรือถูกปิดแล้ว" };
          }
        }
        if (colPublicExpiresAt > 0 && data[i][colPublicExpiresAt - 1]) {
          var exp = new Date(data[i][colPublicExpiresAt - 1]);
          if (!isNaN(exp.getTime()) && new Date() > exp) return { success: false, message: "ลิงก์สาธารณะนี้หมดอายุแล้ว" };
        }
        var expiresText = '';
        if (colPublicExpiresAt > 0 && data[i][colPublicExpiresAt - 1]) {
          var expDate = new Date(data[i][colPublicExpiresAt - 1]);
          if (!isNaN(expDate.getTime())) expiresText = Utilities.formatDate(expDate, "GMT+7", "dd/MM/yyyy HH:mm น.");
        }
        return { success: true, data: { eventName: data[i][1], startTime: Utilities.formatDate(new Date(data[i][2]), "GMT+7", "dd/MM/yyyy HH:mm น."), meetingLink: data[i][4], workStatus: data[i][9], details: data[i][15], location: data[i][16], fileUrl: data[i][14], expiresAt: expiresText } };
      }
    }
    return { success: false, message: "ไม่พบข้อมูลการนัดหมายนี้ หรือข้อมูลอาจถูกลบไปแล้ว" };
  } catch (e) { return { success: false, message: e.toString() }; }
}


function getPendingApprovals(myPhone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NAME);
    var data = sheet.getDataRange().getValues();
    var list = [];
    var targetPhone = myPhone.toString().replace(/'/g, '');
    for (var i = 1; i < data.length; i++) {
      var approvalStatus = data[i][12];
      var approverPhone = data[i][13].toString().replace(/'/g, '');
      if (approvalStatus === "Pending" && approverPhone === targetPhone) {
        list.push({ id: data[i][0], name: data[i][1], owner: data[i][10].toString().replace(/'/g, ''), time: data[i][2] });
      }
    }
    return { success: true, data: list };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}

function updateApprovalStatus(id, status, approverPhone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NAME);
    var data = sheet.getDataRange().getValues();
    for (var i = 1; i < data.length; i++) {
      if (data[i][0] === id) {
        sheet.getRange(i + 1, 13).setValue(status);
        sheet.getRange(i + 1, 14).setValue("'" + approverPhone);
        var chatId = data[i][7];
        if (chatId) {
          sendTelegram("📢 ผลการพิจารณา: งาน '" + data[i][1] + "' ของคุณถูก " + (status === "Approved" ? "✅ อนุมัติ" : "❌ ไม่อนุมัติ") + " แล้วครับ", chatId);
        }
        logAudit_(approverPhone, '', 'UPDATE_APPROVAL', 'Schedule', id, 'อัปเดตสถานะอนุมัติเป็น ' + status, null, {status: status});
        return { success: true, message: "อัปเดตสถานะเรียบร้อย" };
      }
    }
    return { success: false, message: "ไม่พบข้อมูล" };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}


function resetUserPin(phone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_USERS);
    var data = sheet.getDataRange().getValues();
    if (phone.toString() === '0868246621') return { success: false, message: 'ไม่อนุญาตให้รีเซ็ต PIN ของ Master Admin จากหน้านี้' };
    for (var i = 1; i < data.length; i++) {
      if (data[i][0].toString().replace(/'/g, '') === phone.toString().replace(/'/g, '')) {
        var newPin = Math.floor(100000 + Math.random() * 900000).toString();
        sheet.getRange(i + 1, 2).setValue("'" + newPin);
        logAudit_('', 'Admin', 'RESET_PIN', 'User', phone, 'รีเซ็ต PIN ให้ ' + data[i][2], null, {pin: '******'});
        return { success: true, message: 'รีเซ็ต PIN สำเร็จ', pin: newPin, name: data[i][2] };
      }
    }
    return { success: false, message: 'ไม่พบผู้ใช้งาน' };
  } catch(e) { return { success: false, message: e.toString() }; }
}

function setUserActiveStatus(phone, status) {
  try {
    var sheet = getDB().getSheetByName(SHEET_USERS);
    ensureHeaders_(sheet, ['Phone (Username)', 'PIN (Password)', 'Full Name', 'Position', 'Department', 'Email', 'PDPA Status', 'Role', 'Timestamp', 'Email Notify', 'Account Status', 'Last Login'], '#d4edda');
    var statusCol = getColumnIndex_(sheet, 'Account Status');
    var data = sheet.getDataRange().getValues();
    if (phone.toString() === '0868246621') return { success: false, message: 'ไม่อนุญาตให้ปิดบัญชี Master Admin' };
    for (var i = 1; i < data.length; i++) {
      if (data[i][0].toString().replace(/'/g, '') === phone.toString().replace(/'/g, '')) {
        var oldStatus = data[i][statusCol - 1] || 'Active';
        sheet.getRange(i + 1, statusCol).setValue(status);
        logAudit_('', 'Admin', 'UPDATE_ACCOUNT_STATUS', 'User', phone, 'เปลี่ยนสถานะบัญชีจาก ' + oldStatus + ' เป็น ' + status, {status: oldStatus}, {status: status});
        return { success: true, message: 'อัปเดตสถานะบัญชีเรียบร้อย' };
      }
    }
    return { success: false, message: 'ไม่พบผู้ใช้งาน' };
  } catch(e) { return { success: false, message: e.toString() }; }
}

function getDashboardStats() {
  try {
    var ss = getDB();
    var schedSheet = ss.getSheetByName(SHEET_NAME);
    var usersSheet = ss.getSheetByName(SHEET_USERS);
    if (!schedSheet || !usersSheet) {
      return { success: true, totalUsers: 0, totalSchedules: 0, pendingApproval: 0, approved: 0 };
    }
    
    var schedData = schedSheet.getDataRange().getValues();
    var usersData = usersSheet.getDataRange().getValues();
    var pending = 0, approved = 0;
    
    for (var i = 1; i < schedData.length; i++) {
      if (schedData[i][12] === "Pending") {
        pending++;
      } else if (schedData[i][12] === "Approved") {
        approved++;
      }
    }
    return { 
      success: true, 
      totalUsers: usersData.length - 1, 
      totalSchedules: schedData.length - 1, 
      pendingApproval: pending, 
      approved: approved 
    };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}

function getAdminReportData() {
  try {
    var sheet = getDB().getSheetByName(SHEET_REPORTS);
    if (!sheet) {
      return { success: true, data: [] };
    }
    var data = sheet.getDataRange().getValues();
    var report = [];
    for (var i = 1; i < data.length; i++) {
      var d = data[i][1];
      var dateStr = (d instanceof Date) ? Utilities.formatDate(d, "GMT+7", "yyyy-MM-dd") : d;
      report.push({ 
        id: data[i][0], 
        date: dateStr, 
        time: data[i][2], 
        name: data[i][4], 
        dept: data[i][5], 
        leave: data[i][6], 
        details: data[i][7] 
      });
    }
    return { success: true, data: report };
  } catch(e) { 
    return { success: false, message: e.toString() }; 
  }
}



// ==========================================
// AI / Public / Export v1
// ==========================================
function csvEscape_(value) {
  var s = String(value === null || value === undefined ? '' : value);
  s = s.replace(/"/g, '""');
  return '"' + s + '"';
}

function makeCsv_(headers, rows) {
  var lines = ['\uFEFF' + headers.map(csvEscape_).join(',')];
  rows.forEach(function(row) { lines.push(row.map(csvEscape_).join(',')); });
  return lines.join('\n');
}

function formatDateTime_(value, pattern) {
  if (!value) return '';
  var d = value instanceof Date ? value : new Date(value);
  if (isNaN(d.getTime())) return String(value || '');
  return Utilities.formatDate(d, 'GMT+7', pattern || 'yyyy-MM-dd HH:mm');
}

function getSchedulePublicUrlServer(scheduleId, ownerPhone, expiryDays) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NAME);
    if (!sheet) return { success: false, message: 'ไม่พบชีตตารางงาน' };
    ensureHeaders_(sheet, ["ID", "Event Name", "Start Time", "End Time", "Meeting Link", "Visibility", "User Email", "Telegram Chat ID", "Notify Lead Time", "Status", "Owner Phone", "Resource ID", "Approval Status", "Approver Phone", "File URL", "Details", "Location", "Public Enabled", "Public Expires At", "Public Created At"], '#e8f0fe');
    var data = sheet.getDataRange().getValues();
    var targetPhone = ownerPhone ? ownerPhone.toString().replace(/'/g, '') : '';
    var colEnabled = getColumnIndex_(sheet, 'Public Enabled');
    var colExpires = getColumnIndex_(sheet, 'Public Expires At');
    var colCreated = getColumnIndex_(sheet, 'Public Created At');
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][0]) === String(scheduleId)) {
        var rowPhone = String(data[i][10] || '').replace(/'/g, '');
        if (targetPhone && rowPhone !== targetPhone) return { success: false, message: 'คุณไม่มีสิทธิ์สร้างลิงก์สาธารณะของรายการนี้' };
        var expiresAt = '';
        var days = Number(expiryDays || getSetting_('PUBLIC_LINK_EXPIRY_DAYS', 30));
        if (days > 0) {
          expiresAt = new Date(new Date().getTime() + days * 24 * 60 * 60 * 1000);
          sheet.getRange(i + 1, colExpires).setValue(expiresAt);
        } else {
          sheet.getRange(i + 1, colExpires).setValue('');
        }
        sheet.getRange(i + 1, colEnabled).setValue('TRUE');
        sheet.getRange(i + 1, colCreated).setValue(new Date());
        var url = getWebAppUrl() + '?publicId=' + encodeURIComponent(scheduleId);
        logAudit_(ownerPhone, '', 'CREATE_PUBLIC_LINK', 'Schedule', scheduleId, 'สร้าง/เปิดลิงก์สาธารณะ', null, { url: url, expiryDays: days });
        return { success: true, url: url, expiresAt: expiresAt ? formatDateTime_(expiresAt, 'dd/MM/yyyy HH:mm') : 'ไม่หมดอายุ' };
      }
    }
    return { success: false, message: 'ไม่พบรายการที่ต้องการสร้างลิงก์' };
  } catch(e) { return { success: false, message: e.toString() }; }
}

function revokePublicScheduleLink(scheduleId, ownerPhone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NAME);
    if (!sheet) return { success: false, message: 'ไม่พบชีตตารางงาน' };
    var data = sheet.getDataRange().getValues();
    var colEnabled = getColumnIndex_(sheet, 'Public Enabled');
    if (colEnabled < 0) return { success: true, message: 'ยังไม่มี public link ให้ปิด' };
    var targetPhone = ownerPhone ? ownerPhone.toString().replace(/'/g, '') : '';
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][0]) === String(scheduleId)) {
        var rowPhone = String(data[i][10] || '').replace(/'/g, '');
        if (targetPhone && rowPhone !== targetPhone) return { success: false, message: 'คุณไม่มีสิทธิ์ปิดลิงก์นี้' };
        sheet.getRange(i + 1, colEnabled).setValue('FALSE');
        logAudit_(ownerPhone, '', 'REVOKE_PUBLIC_LINK', 'Schedule', scheduleId, 'ปิดลิงก์สาธารณะ', null, null);
        return { success: true, message: 'ปิดลิงก์สาธารณะแล้ว' };
      }
    }
    return { success: false, message: 'ไม่พบรายการ' };
  } catch(e) { return { success: false, message: e.toString() }; }
}

function exportDailyReportsCsv() {
  try {
    var sheet = getDB().getSheetByName(SHEET_REPORTS);
    if (!sheet) return { success: false, message: 'ไม่พบชีตรายงาน' };
    var data = sheet.getDataRange().getValues(), rows = [];
    for (var i = 1; i < data.length; i++) rows.push([data[i][0], formatDateTime_(data[i][1], 'yyyy-MM-dd'), data[i][2], String(data[i][3]).replace(/'/g,''), data[i][4], data[i][5], data[i][6], data[i][7], data[i][8], data[i][9]]);
    return { success: true, filename: 'daily_reports_' + Utilities.formatDate(new Date(), 'GMT+7', 'yyyyMMdd_HHmm') + '.csv', content: makeCsv_(['Report ID','Date','Time','User Phone','User Name','Department','Leave Type','Work Details','Remarks','File URL'], rows) };
  } catch(e) { return { success: false, message: e.toString() }; }
}

function exportSchedulesCsv(ownerPhone, role) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NAME);
    if (!sheet) return { success: false, message: 'ไม่พบชีตตารางงาน' };
    var data = sheet.getDataRange().getValues(), rows = [];
    var targetPhone = ownerPhone ? ownerPhone.toString().replace(/'/g, '') : '';
    var isAdmin = role === 'Super Admin' || role === 'Admin';
    for (var i = 1; i < data.length; i++) {
      var rowPhone = String(data[i][10] || '').replace(/'/g, '');
      if (!isAdmin && targetPhone && rowPhone !== targetPhone) continue;
      rows.push([data[i][0], data[i][1], formatDateTime_(data[i][2], 'yyyy-MM-dd HH:mm'), data[i][9], data[i][12], rowPhone, data[i][16], data[i][15], data[i][4], data[i][14]]);
    }
    return { success: true, filename: 'schedules_' + Utilities.formatDate(new Date(), 'GMT+7', 'yyyyMMdd_HHmm') + '.csv', content: makeCsv_(['ID','Event Name','Start Time','Work Status','Approval Status','Owner Phone','Location','Details','Meeting Link','File URL'], rows) };
  } catch(e) { return { success: false, message: e.toString() }; }
}

function getOnePageSummaryData(ownerPhone, role) {
  try {
    var ss = getDB(), schedSheet = ss.getSheetByName(SHEET_NAME), reportSheet = ss.getSheetByName(SHEET_REPORTS);
    var scheduleData = schedSheet ? schedSheet.getDataRange().getValues() : [];
    var reportData = reportSheet ? reportSheet.getDataRange().getValues() : [];
    var targetPhone = ownerPhone ? ownerPhone.toString().replace(/'/g, '') : '';
    var isAdmin = role === 'Super Admin' || role === 'Admin';
    var today = new Date(), todayStr = Utilities.formatDate(today, 'GMT+7', 'yyyy-MM-dd');
    var statusCount = {}, approvalCount = {}, todaySchedules = [], dueSoon = [], totalSchedules = 0;
    for (var i = 1; i < scheduleData.length; i++) {
      var rowPhone = String(scheduleData[i][10] || '').replace(/'/g, '');
      if (!isAdmin && targetPhone && rowPhone !== targetPhone) continue;
      totalSchedules++;
      var st = scheduleData[i][9] || 'ไม่ระบุ', ap = scheduleData[i][12] || 'ไม่ระบุ';
      statusCount[st] = (statusCount[st] || 0) + 1; approvalCount[ap] = (approvalCount[ap] || 0) + 1;
      var startDt = new Date(scheduleData[i][2]);
      if (!isNaN(startDt.getTime())) {
        var dStr = Utilities.formatDate(startDt, 'GMT+7', 'yyyy-MM-dd');
        var diff = (startDt - today) / (1000 * 60 * 60 * 24);
        var item = { name: scheduleData[i][1], time: formatDateTime_(startDt, 'dd/MM/yyyy HH:mm'), status: st, location: scheduleData[i][16] || '' };
        if (dStr === todayStr) todaySchedules.push(item);
        if (diff >= 0 && diff <= 7) dueSoon.push(item);
      }
    }
    var todayReports = 0;
    for (var j = 1; j < reportData.length; j++) {
      var repPhone = String(reportData[j][3] || '').replace(/'/g, '');
      if (!isAdmin && targetPhone && repPhone !== targetPhone) continue;
      var repDate = reportData[j][1] instanceof Date ? Utilities.formatDate(reportData[j][1], 'GMT+7', 'yyyy-MM-dd') : String(reportData[j][1]);
      if (repDate === todayStr) todayReports++;
    }
    return { success: true, data: { generatedAt: formatDateTime_(new Date(), 'dd/MM/yyyy HH:mm'), totalSchedules: totalSchedules, todayReports: todayReports, todaySchedules: todaySchedules.slice(0, 12), dueSoon: dueSoon.slice(0, 12), statusCount: statusCount, approvalCount: approvalCount } };
  } catch(e) { return { success: false, message: e.toString() }; }
}

function generateExecutiveSummaryAI(ownerPhone, role) {
  try {
    var dataRes = getOnePageSummaryData(ownerPhone, role);
    if (!dataRes.success) return dataRes;
    var prompt = 'คุณคือผู้ช่วยสรุปงานสำหรับผู้บริหาร สรุปข้อมูล Health Assistant OS ต่อไปนี้เป็นภาษาไทยแบบกระชับ ใช้หัวข้อย่อย ชี้ประเด็นงานเร่งด่วน ความเสี่ยง และข้อเสนอแนะ ไม่เกิน 12 บรรทัด:\n' + JSON.stringify(dataRes.data);
    var ai = fetchGeminiAI(prompt, null, null);
    if (!ai.success) return { success: false, message: ai.message };
    return { success: true, data: ai.text, rawData: dataRes.data };
  } catch(e) { return { success: false, message: e.toString() }; }
}

function aiPolishOfficialText(text) {
  try {
    var prompt = 'ปรับข้อความต่อไปนี้ให้เป็นภาษาราชการ กระชับ สุภาพ และชัดเจน โดยไม่เพิ่มข้อเท็จจริงใหม่:\n\n' + text;
    var ai = fetchGeminiAI(prompt, null, null);
    if (!ai.success) return { success: false, message: ai.message };
    return { success: true, data: ai.text };
  } catch(e) { return { success: false, message: e.toString() }; }
}


// =======================================================
// 🚀 AI ENGINE CORE: Production-Ready (Gemini 2.5 Flash)
// =======================================================
function fetchGeminiAI(prompt, base64Data, mimeType) {
  try {
    var apiKey = getGeminiApiKey_();
    if (!apiKey || apiKey.trim() === "") {
      return { success: false, message: "ยังไม่ได้ตั้งค่า GEMINI_API_KEY ใน Script Properties" };
    }

    var parts = [{ text: String(prompt || "") }];

    if (base64Data && mimeType) {
      parts.push({
        inline_data: {
          mime_type: mimeType,
          data: base64Data
        }
      });
    }

    var payload = {
      contents: [
        {
          role: "user",
          parts: parts
        }
      ],
      generationConfig: {
        temperature: 0.3,
        topP: 0.9,
        maxOutputTokens: 2048
      }
    };

    var models = [
      "gemini-2.5-flash",
      "gemini-2.5-flash-lite",
      "gemini-2.5-pro"
    ];

    var lastError = "";

    for (var i = 0; i < models.length; i++) {
      var model = models[i];
      var url =
        "https://generativelanguage.googleapis.com/v1beta/models/" +
        model +
        ":generateContent?key=" +
        encodeURIComponent(apiKey);

      var options = {
        method: "post",
        contentType: "application/json",
        payload: JSON.stringify(payload),
        muteHttpExceptions: true
      };

      var response = UrlFetchApp.fetch(url, options);
      var code = response.getResponseCode();
      var body = response.getContentText();

      var json;
      try {
        json = JSON.parse(body);
      } catch (parseErr) {
        lastError = "HTTP " + code + " | Invalid JSON response: " + body;
        continue;
      }

      if (
        code >= 200 &&
        code < 300 &&
        json.candidates &&
        json.candidates.length > 0 &&
        json.candidates[0].content &&
        json.candidates[0].content.parts &&
        json.candidates[0].content.parts.length > 0
      ) {
        return {
          success: true,
          text: json.candidates[0].content.parts[0].text || "",
          model: model
        };
      }

      if (json.error && json.error.message) {
        lastError = "HTTP " + code + " | " + model + " | " + json.error.message;
      } else {
        lastError = "HTTP " + code + " | " + model + " | " + body;
      }
    }

    return {
      success: false,
      message: lastError || "ไม่สามารถเรียก Gemini API ได้"
    };

  } catch (e) {
    return {
      success: false,
      message: e.toString()
    };
  }
}


// ==========================================
// JSON Utility: ทำให้การอ่าน JSON จาก Gemini ทนมือขึ้น
// ==========================================
function normalizeJsonString_(jsonText) {
  var out = "";
  var inString = false;
  var escaped = false;

  for (var i = 0; i < jsonText.length; i++) {
    var ch = jsonText.charAt(i);

    if (escaped) {
      out += ch;
      escaped = false;
      continue;
    }

    if (ch === "\\") {
      out += ch;
      escaped = true;
      continue;
    }

    if (ch === '"') {
      inString = !inString;
      out += ch;
      continue;
    }

    // Gemini บางครั้งใส่ขึ้นบรรทัดใหม่จริง ๆ ใน value ทำให้ JSON.parse พัง
    if (inString && ch === "\n") {
      out += "\\n";
      continue;
    }
    if (inString && ch === "\r") {
      continue;
    }
    if (inString && ch === "\t") {
      out += "\\t";
      continue;
    }

    out += ch;
  }

  return out;
}

function parseGeminiJson_(text) {
  if (text === null || text === undefined) {
    throw new Error("AI ไม่ได้ส่งข้อความกลับมา");
  }

  var raw = String(text)
    .replace(/```json/gi, "")
    .replace(/```/g, "")
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .trim();

  var first = raw.indexOf("{");
  var last = raw.lastIndexOf("}");

  if (first === -1 || last === -1 || last <= first) {
    throw new Error("AI ไม่ได้ส่ง JSON object ที่สมบูรณ์กลับมา: " + raw.substring(0, 300));
  }

  var jsonText = raw.substring(first, last + 1);

  var candidates = [];
  candidates.push(jsonText);
  candidates.push(jsonText.replace(/,\s*([}\]])/g, "$1"));
  candidates.push(normalizeJsonString_(jsonText).replace(/,\s*([}\]])/g, "$1"));

  var lastErr = null;
  for (var i = 0; i < candidates.length; i++) {
    try {
      return JSON.parse(candidates[i]);
    } catch (err) {
      lastErr = err;
    }
  }

  throw new Error("แปลง JSON จาก AI ไม่สำเร็จ: " + lastErr + " | ตัวอย่างข้อมูล: " + jsonText.substring(0, 500));
}

// -------------------------------------------------------
// 🚀 AI Wrappers (เรียกใช้ fetchGeminiAI ตัวใหม่ทั้งหมด)
// -------------------------------------------------------

function analyzeLineMessage(text) {
  try {
    var prompt = "จงวิเคราะห์ข้อความแจ้งงาน (มักถูก Forward มาจาก LINE) นี้ แล้วสรุปข้อมูลเพื่อเอาไปลงตารางงาน โดยตอบกลับเป็น JSON object เท่านั้น ห้ามมี markdown ห้ามมีข้อความอื่นปน และห้ามใส่ line break จริงในค่า string ให้ใช้ \\n แทน:\n" +
                 "{\n" +
                 "  \"event_name\": \"ชื่องาน/การประชุม แบบสั้นๆ กระชับ\",\n" +
                 "  \"date_time\": \"วันเวลาที่ต้องทำ (ดึงจากข้อความแล้วแปลงเป็นรูปแบบ YYYY-MM-DDTHH:MM ถ้าไม่มีในข้อความให้ใส่เป็นสตริงว่าง)\",\n" +
                 "  \"action_details\": \"สรุปว่าต้องทำอะไรบ้าง หรือรายละเอียดเพิ่มเติม (Action Items)\",\n" +
                 "  \"meeting_link\": \"สกัดลิงก์ Zoom, Google Meet (ถ้ามี)\"\n" +
                 "}\n\nข้อความ:\n" + text;
                 
    var aiResult = fetchGeminiAI(prompt, null, null);
    
    if (!aiResult.success) {
      return { success: false, message: "AI Error: " + aiResult.message };
    }
    
    var aiText = aiResult.text;
    return { success: true, data: parseGeminiJson_(aiText), raw: aiText };

  } catch (e) {
    return { success: false, message: "ระบบประมวลผลขัดข้อง: " + e.toString() };
  }
}

function generateHeadSummaryAI(reportsData) {
  try {
    if (!reportsData || reportsData.length === 0) {
      return { success: false, message: "ไม่มีข้อมูลรายงานในวันนี้ให้สรุปครับ" };
    }
    
    var rawText = "ข้อมูลการทำงานวันนี้:\n";
    for(var i=0; i < reportsData.length; i++) {
       rawText += "- " + reportsData[i].name + " (" + reportsData[i].leaveType + "): " + reportsData[i].details + "\n";
    }

    var prompt = "คุณคือ AI ผู้ช่วยสรุปงานสำหรับผู้บริหาร จงสรุปข้อความด้านล่างนี้ให้เป็น 'รายงานภาพรวมประจำวัน' แบบมืออาชีพ กระชับ อ่านง่าย แบ่งเป็นข้อๆ ว่าวันนี้ทีมงานทำอะไรสำเร็จไปบ้าง ใครลาบ้าง:\n\n" + rawText;
    
    var aiResult = fetchGeminiAI(prompt, null, null);
    
    if (!aiResult.success) {
      return { success: false, message: "AI Error: " + aiResult.message };
    }
    return { success: true, data: aiResult.text };

  } catch(e) {
    return { success: false, message: e.toString() };
  }
}

function chatWithAI(text) {
  var prompt = "คุณคือเลขา AI สสจ.นครนายก ตอบสั้นๆ เป็นกันเอง: " + text;
  var aiResult = fetchGeminiAI(prompt, null, null);
  if (!aiResult.success) {
    return "ขออภัยครับ ระบบ AI ขัดข้อง: " + aiResult.message;
  }
  return aiResult.text;
}

function analyzeChatWithGemini(text) {
  return chatWithAI(text);
}

function analyzeImageWithAI(base64Data, mimeType) {
  try {
    var prompt = "คุณคือเลขาฯ อัจฉริยะ จงวิเคราะห์รูปภาพหรือเอกสารนี้ แล้วสรุปข้อมูลตอบกลับมาเป็น JSON object เท่านั้น ห้ามมี markdown ห้ามมีข้อความอื่นปน และห้ามใส่ line break จริงในค่า string ให้ใช้ \\n แทน:\n" +
                 "{\n  \"summary\": \"สรุปสาระสำคัญ\",\n  \"event_name\": \"ชื่อการประชุม/งาน\",\n  \"date_time\": \"วันเวลา (YYYY-MM-DDTHH:MM) ถ้าไม่มีให้ใส่ค่าว่าง\",\n  \"meeting_link\": \"ลิงก์ Zoom/Meet (ถ้ามี)\",\n  \"draft_memo\": \"ร่างบันทึกข้อความ\"\n}";

    var aiResult = fetchGeminiAI(prompt, base64Data, mimeType);
    
    if (!aiResult.success) {
      return { success: false, message: "Google API Error: " + aiResult.message };
    }

    var aiText = aiResult.text;
    aiText = aiText.replace(/```json/g, "").replace(/```/g, "").trim(); 
    
    return { success: true, data: parseGeminiJson_(aiText), raw: aiText, modelUsed: aiResult.model };

  } catch (e) { 
    return { success: false, message: "ระบบขัดข้องในการแปลงข้อมูล: " + e.toString() }; 
  }
}

function processDocument(base64Data, fileName, mimeType) {
  return analyzeImageWithAI(base64Data, mimeType);
}

function testListGeminiModels() {
  var apiKey = getGeminiApiKey_();
  if (!apiKey) throw new Error("ยังไม่ได้ตั้งค่า GEMINI_API_KEY ใน Script Properties");
  var url = "https://generativelanguage.googleapis.com/v1beta/models?key=" + encodeURIComponent(apiKey);
  var res = UrlFetchApp.fetch(url, {
    method: "get",
    muteHttpExceptions: true
  });
  Logger.log(res.getResponseCode());
  Logger.log(res.getContentText());
}


// ==========================================
// Webhook & Automation
// ==========================================
function setupTelegramWebhook(webAppUrl) {
  if (!webAppUrl || webAppUrl === "") {
    return { success: false, message: "ไม่พบ Web App URL" };
  }
  var token = getTelegramBotToken_();
  if (!token) return { success: false, message: "ยังไม่ได้ตั้งค่า BOT_TOKEN ใน Script Properties" };
  UrlFetchApp.fetch("https://api.telegram.org/bot" + token + "/setWebhook?url=" + webAppUrl);
  return { success: true, message: "ผูก Webhook สำเร็จ!" };
}

function jsonOutput_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function getVercelApiSecret_() {
  return getScriptProp_('VERCEL_API_SECRET', FALLBACK_VERCEL_API_SECRET);
}

function getAllowedBridgeFunctions_() {
  return {
    getWebAppUrl:true, Setup:true, loginAccount:true, registerAccount:true, updateUserProfile:true, getAllUsers:true, getAdminUsersData:true, adminAddNewUser:true, updateUserRole:true, resetUserPin:true, setUserActiveStatus:true, deleteUserAccount:true, getSystemHealth:true, getAuditLogs:true, addResource:true, deleteResource:true, getAvailableResources:true, getNotifications:true, markNotifAsRead:true, uploadFileToDrive:true, saveDailyReport:true, deleteDailyReport:true, getMyReports:true, getTeamReports:true, getDashboardStats:true, getUserSchedules:true, saveScheduleV2:true, updateScheduleV2:true, deleteSchedule:true, syncToGoogleCalendar:true, getPendingApprovals:true, updateApprovalStatus:true, analyzeLineMessage:true, processDocument:true, analyzeImageWithAI:true, chatWithAI:true, generateHeadSummaryAI:true, generateExecutiveSummaryAI:true, getSchedulePublicUrlServer:true, revokePublicScheduleLink:true, getPublicSchedule:true, exportDailyReportsCsv:true, exportSchedulesCsv:true, getOnePageSummaryData:true, manageAutomation:true, setupTelegramWebhook:true, getMyRecurringRules:true, toggleRecurringRule:true, deleteRecurringRule:true, generateDueRecurringSchedules:true, workflowSetup:true
  };
}

function handleVercelBridge_(payload) {
  var expected = getVercelApiSecret_();
  if (!expected || payload.secret !== expected) return { __bridgeError:true, success:false, message:'Unauthorized Vercel bridge request' };
  var fnName = payload.fn;
  var allowed = getAllowedBridgeFunctions_();
  if (!allowed[fnName]) return { __bridgeError:true, success:false, message:'Function not allowed: ' + fnName };
  var fn = (typeof globalThis !== 'undefined' ? globalThis[fnName] : this[fnName]);
  if (typeof fn !== 'function') { try { fn = eval(fnName); } catch (ignore) {} }
  if (typeof fn !== 'function') return { __bridgeError:true, success:false, message:'Function not found: ' + fnName };
  try { return fn.apply(null, payload.args || []); } catch (err) { return { __bridgeError:true, success:false, message:err.toString() }; }
}

function doPost(e) {
  try {
    if (e && e.postData && e.postData.type === "application/json") {
      var payload = JSON.parse(e.postData.contents || '{}');
      if (payload && payload._vercelBridge) return jsonOutput_(handleVercelBridge_(payload));
      var update = payload;
      if (update.message && update.message.text) {
        var chatId = update.message.chat.id;
        var text = update.message.text.trim();
        if (text === "/start") sendTelegram("👋 พิมพ์ /mywork เพื่อดูงานวันนี้ครับ", chatId);
        else if (text === "/mywork") {
          var data = getDB().getSheetByName(SHEET_NAME).getDataRange().getValues();
          var works = [];
          for (var i = 1; i < data.length; i++) {
            if (data[i][7].toString() === chatId.toString() && data[i][9] === "Pending") works.push("🗓 " + data[i][1] + " (" + Utilities.formatDate(new Date(data[i][2]), "GMT+7", "HH:mm") + ")");
          }
          sendTelegram(works.length > 0 ? "💼 งานของคุณ:\n" + works.join("\n") : "✅ ไม่มีงานรอแจ้งเตือน", chatId);
        } else sendTelegram("🤖: " + chatWithAI(text), chatId);
      }
    }
  } catch (error) { Logger.log(error); }
  return ContentService.createTextOutput("OK");
}


function manageAutomation(status) {
  var value = (status === 'on' || status === 'ON') ? 'ON' : 'OFF';
  setSetting_('SYSTEM_STATUS', value, 'สถานะการแจ้งเตือน/ระบบอัตโนมัติ');
  logAudit_('', 'Admin', 'UPDATE_SYSTEM_STATUS', 'Settings', 'SYSTEM_STATUS', 'เปลี่ยนสถานะระบบเป็น ' + value, null, {status: value});
  return { success: true, message: value === 'ON' ? 'เปิดระบบแจ้งเตือน/บอทแล้ว' : 'ปิดระบบแจ้งเตือน/บอทแล้ว' };
}


function mainWorkflow() { 
  checkAndNotify(); 
}

function checkAndNotify() {
  if (getSetting_("SYSTEM_STATUS", "ON") === "OFF") return;
  var ss = getDB();
  var sheet = ss.getSheetByName(SHEET_NAME);
  var userSheet = ss.getSheetByName(SHEET_USERS);
  
  if (!sheet || !userSheet) return;
  var data = sheet.getDataRange().getValues();
  var usersData = userSheet.getDataRange().getValues();
  var now = new Date();
  
  var emailNotifMap = {};
  for(var u = 1; u < usersData.length; u++) {
     emailNotifMap[usersData[u][0].toString().replace(/'/g, '')] = usersData[u][9] || "On";
  }
  
  for (var i = 1; i < data.length; i++) {
    if (data[i][9] === "อยู่ระหว่างการดำเนินการ" && data[i][12] === "Approved") {
      var startTime = new Date(data[i][2]);
      if (now >= new Date(startTime.getTime() - (data[i][8] * 60000)) && now < startTime) {
        var msg = "🔔 [แจ้งเตือนงาน]\nเรื่อง: " + data[i][1] + "\nเวลา: " + Utilities.formatDate(startTime, "GMT+7", "HH:mm น.");
        
        if (data[i][15] && data[i][15] !== "") {
          msg += "\n📝 รายละเอียด: " + data[i][15];
        }
        if (data[i][16] && data[i][16] !== "") {
          msg += "\n📍 สถานที่: " + data[i][16];
        }
        if (data[i][4] && data[i][4] !== "") {
          msg += "\n🔗 ลิงก์เข้าร่วม: " + data[i][4];
        }
        if (data[i][7]) {
          sendTelegram(msg, data[i][7]);
        }
        
        var ownerPhone = data[i][10].toString().replace(/'/g, '');
        if (data[i][6] && emailNotifMap[ownerPhone] !== "Off") {
          MailApp.sendEmail(data[i][6], "แจ้งเตือนงาน", msg);
        }
        
        sheet.getRange(i + 1, 10).setValue("Notified");
      }
    }
  }
}

function sendTelegram(msg, chatId) {
  if (!msg || msg === "" || !chatId || chatId === "") return;
  var options = {
    "method": "post",
    "contentType": "application/json",
    "payload": JSON.stringify({"chat_id": String(chatId), "text": String(msg)}),
    "muteHttpExceptions": true
  };
  var token = getTelegramBotToken_();
  if (!token) return;
  UrlFetchApp.fetch("https://api.telegram.org/bot" + token + "/sendMessage", options);
}
// ==========================================
// Workflow Automation v1: Recurring Tasks + Approval Flow
// ==========================================
function workflowSetup() {
  getOrCreateSheet_(SHEET_RECURRING, [
    'Rule ID', 'Owner Phone', 'Owner Name', 'Event Name', 'Details', 'Location', 'Meeting Link', 'Resource ID',
    'Lead Time', 'Work Status', 'Frequency', 'Interval', 'By Day', 'Start Date', 'End Date', 'Next Run', 'Active', 'Last Run', 'Created At'
  ], '#dcfce7');
  getOrCreateSheet_('ApprovalHistory', ['History ID', 'Schedule ID', 'Action', 'Actor Phone', 'Reason', 'Timestamp'], '#fef3c7');
  return { success: true, message: 'Workflow tables are ready' };
}

function saveRecurringRule(rule) {
  try {
    workflowSetup();
    var sheet = getDB().getSheetByName(SHEET_RECURRING);
    var ruleId = 'REC-' + Utilities.getUuid().substring(0, 8);
    var start = rule.startDate ? new Date(rule.startDate) : new Date();
    var nextRun = calculateNextRun_(start, rule.frequency || 'weekly', Number(rule.interval || 1), rule.byDay || '', true);
    sheet.appendRow([
      ruleId,
      "'" + String(rule.ownerPhone || ''),
      rule.ownerName || '',
      rule.eventName || '',
      rule.details || '',
      rule.location || '',
      rule.meetingLink || '',
      rule.resourceId || '',
      rule.leadTime || 15,
      rule.workStatus || 'อยู่ระหว่างการดำเนินการ',
      rule.frequency || 'weekly',
      Number(rule.interval || 1),
      rule.byDay || '',
      start,
      rule.endDate || '',
      nextRun,
      true,
      '',
      new Date()
    ]);
    logAudit_(rule.ownerPhone || '', rule.ownerName || '', 'CREATE_RECURRING_RULE', 'RecurringRule', ruleId, 'สร้างงานประจำ: ' + (rule.eventName || ''), null, rule);
    return { success: true, message: 'สร้างกฎงานประจำเรียบร้อย', ruleId: ruleId };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

function getMyRecurringRules(ownerPhone) {
  try {
    workflowSetup();
    var sheet = getDB().getSheetByName(SHEET_RECURRING);
    var data = sheet.getDataRange().getValues();
    var target = String(ownerPhone || '').replace(/'/g, '');
    var result = [];
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][1]).replace(/'/g, '') === target) {
        result.push({
          id: data[i][0],
          eventName: data[i][3],
          frequency: data[i][10],
          interval: data[i][11] || 1,
          byDay: data[i][12] || '',
          startDate: data[i][13] instanceof Date ? Utilities.formatDate(data[i][13], 'GMT+7', 'dd/MM/yyyy') : data[i][13],
          endDate: data[i][14] instanceof Date ? Utilities.formatDate(data[i][14], 'GMT+7', 'dd/MM/yyyy') : data[i][14],
          nextRun: data[i][15] instanceof Date ? Utilities.formatDate(data[i][15], 'GMT+7', 'dd/MM/yyyy HH:mm') : data[i][15],
          active: data[i][16] === true || String(data[i][16]).toUpperCase() === 'TRUE'
        });
      }
    }
    return { success: true, data: result.reverse() };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

function toggleRecurringRule(ruleId, active, ownerPhone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_RECURRING);
    var data = sheet.getDataRange().getValues();
    var target = String(ownerPhone || '').replace(/'/g, '');
    for (var i = 1; i < data.length; i++) {
      if (data[i][0] === ruleId && String(data[i][1]).replace(/'/g, '') === target) {
        sheet.getRange(i + 1, 17).setValue(!!active);
        logAudit_(ownerPhone, '', active ? 'ENABLE_RECURRING_RULE' : 'DISABLE_RECURRING_RULE', 'RecurringRule', ruleId, (active ? 'เปิด' : 'ปิด') + 'งานประจำ', null, {active: !!active});
        return { success: true, message: active ? 'เปิดใช้งานงานประจำแล้ว' : 'ปิดใช้งานงานประจำแล้ว' };
      }
    }
    return { success: false, message: 'ไม่พบกฎงานประจำ หรือคุณไม่มีสิทธิ์จัดการ' };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

function deleteRecurringRule(ruleId, ownerPhone) {
  try {
    var sheet = getDB().getSheetByName(SHEET_RECURRING);
    var data = sheet.getDataRange().getValues();
    var target = String(ownerPhone || '').replace(/'/g, '');
    for (var i = 1; i < data.length; i++) {
      if (data[i][0] === ruleId && String(data[i][1]).replace(/'/g, '') === target) {
        var name = data[i][3];
        sheet.deleteRow(i + 1);
        logAudit_(ownerPhone, '', 'DELETE_RECURRING_RULE', 'RecurringRule', ruleId, 'ลบงานประจำ: ' + name, null, null);
        return { success: true, message: 'ลบงานประจำเรียบร้อยแล้ว' };
      }
    }
    return { success: false, message: 'ไม่พบกฎงานประจำ หรือคุณไม่มีสิทธิ์ลบ' };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

function generateDueRecurringSchedules() {
  try {
    workflowSetup();
    var sheet = getDB().getSheetByName(SHEET_RECURRING);
    var data = sheet.getDataRange().getValues();
    var now = new Date();
    var created = 0;
    for (var i = 1; i < data.length; i++) {
      var active = data[i][16] === true || String(data[i][16]).toUpperCase() === 'TRUE';
      if (!active) continue;
      var nextRun = data[i][15] ? new Date(data[i][15]) : null;
      if (!nextRun || isNaN(nextRun.getTime()) || nextRun > now) continue;
      var endDate = data[i][14] ? new Date(data[i][14]) : null;
      if (endDate && !isNaN(endDate.getTime()) && now > endDate) {
        sheet.getRange(i + 1, 17).setValue(false);
        continue;
      }
      createScheduleFromRecurring_(data[i]);
      created++;
      var frequency = data[i][10] || 'weekly';
      var interval = Number(data[i][11] || 1);
      var byDay = data[i][12] || '';
      var newNext = calculateNextRun_(nextRun, frequency, interval, byDay, false);
      sheet.getRange(i + 1, 16).setValue(newNext);
      sheet.getRange(i + 1, 18).setValue(new Date());
    }
    return { success: true, message: 'สร้างงานประจำที่ถึงกำหนดแล้ว ' + created + ' รายการ', created: created };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

function createScheduleFromRecurring_(row) {
  var start = row[15] ? new Date(row[15]) : new Date();
  var data = {
    ownerPhone: String(row[1]).replace(/'/g, ''),
    ownerName: row[2] || '',
    eventName: row[3] || '',
    details: row[4] || '',
    location: row[5] || '',
    meetingLink: row[6] || '',
    resourceId: row[7] || '',
    leadTime: row[8] || 15,
    workStatus: row[9] || 'อยู่ระหว่างการดำเนินการ',
    startTime: Utilities.formatDate(start, 'GMT+7', "yyyy-MM-dd'T'HH:mm"),
    userEmail: '',
    chatId: '',
    assignees: [],
    fileUrl: '',
    approverPhone: '',
    visibility: 'Private'
  };
  return saveScheduleV2(data);
}

function calculateNextRun_(baseDate, frequency, interval, byDay, firstRun) {
  var d = new Date(baseDate);
  interval = Math.max(1, Number(interval || 1));
  if (!firstRun) {
    if (frequency === 'daily') d.setDate(d.getDate() + interval);
    else if (frequency === 'workday') {
      do { d.setDate(d.getDate() + 1); } while (d.getDay() === 0 || d.getDay() === 6);
    }
    else if (frequency === 'monthly') d.setMonth(d.getMonth() + interval);
    else d.setDate(d.getDate() + (7 * interval));
  }
  if (frequency === 'weekly' && byDay) {
    var map = {SU:0, MO:1, TU:2, WE:3, TH:4, FR:5, SA:6};
    var target = map[String(byDay).toUpperCase()];
    if (target !== undefined) {
      var guard = 0;
      while (d.getDay() !== target && guard < 8) { d.setDate(d.getDate() + 1); guard++; }
    }
  }
  return d;
}

// Override: richer approval status with reason + history + owner notification.
function updateApprovalStatus(id, status, approverPhone, reason) {
  try {
    var sheet = getDB().getSheetByName(SHEET_NAME);
    var data = sheet.getDataRange().getValues();
    var history = getOrCreateSheet_('ApprovalHistory', ['History ID', 'Schedule ID', 'Action', 'Actor Phone', 'Reason', 'Timestamp'], '#fef3c7');
    for (var i = 1; i < data.length; i++) {
      if (data[i][0] === id) {
        sheet.getRange(i + 1, 13).setValue(status);
        sheet.getRange(i + 1, 14).setValue("'" + approverPhone);
        var ownerPhone = String(data[i][10]).replace(/'/g, '');
        var eventName = data[i][1];
        var msgMap = { Approved: '✅ อนุมัติแล้ว', Rejected: '❌ ไม่อนุมัติ', RevisionRequested: '📝 ขอให้แก้ไขข้อมูล' };
        var statusText = msgMap[status] || status;
        history.appendRow(['APR-' + Utilities.getUuid().substring(0, 8), id, status, "'" + approverPhone, reason || '', new Date()]);
        var notifSheet = getDB().getSheetByName(SHEET_NOTIFICATIONS) || getOrCreateSheet_(SHEET_NOTIFICATIONS, ['Notif ID', 'Target Phone', 'Message', 'Is Read', 'Timestamp'], '#f8d7da');
        notifSheet.appendRow(['NTF-' + Utilities.getUuid().substring(0, 5), "'" + ownerPhone, 'ผลการพิจารณางาน: ' + eventName + ' - ' + statusText + (reason ? ' | หมายเหตุ: ' + reason : ''), false, new Date()]);
        var chatId = data[i][7];
        if (chatId) sendTelegram('📢 ผลการพิจารณา: ' + eventName + '\nสถานะ: ' + statusText + (reason ? '\nหมายเหตุ: ' + reason : ''), chatId);
        logAudit_(approverPhone, '', 'UPDATE_APPROVAL', 'Schedule', id, 'อัปเดตสถานะอนุมัติเป็น ' + statusText, null, {status: status, reason: reason || ''});
        return { success: true, message: 'อัปเดตสถานะเรียบร้อย' };
      }
    }
    return { success: false, message: 'ไม่พบข้อมูล' };
  } catch(e) {
    return { success: false, message: e.toString() };
  }
}
