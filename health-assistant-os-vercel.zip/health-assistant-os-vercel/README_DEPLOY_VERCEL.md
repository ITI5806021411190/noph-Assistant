# Health Assistant OS on Vercel

ชุดนี้ทำให้หน้าเว็บ Health Assistant OS เปิดผ่านโดเมนฟรีของ Vercel เช่น `https://your-project.vercel.app` ได้ โดยยังใช้ Google Apps Script เป็น backend เดิมสำหรับ Google Sheet, Drive, Calendar, Telegram และ Gemini

## Secret ที่สร้างให้

```text
VERCEL_API_SECRET=HAOS_1777448392812_5f154d07d5ca59a27854741941470dc3
GAS_API_SECRET=HAOS_1777448392812_5f154d07d5ca59a27854741941470dc3
```

## ขั้นตอน Apps Script

1. แทนที่ `Code.gs` ด้วย `Code_for_AppsScript_v11.gs`
2. ตั้ง Script properties:

```text
VERCEL_API_SECRET=HAOS_1777448392812_5f154d07d5ca59a27854741941470dc3
GEMINI_API_KEY=ใส่ key จริงของคุณ
BOT_TOKEN=ใส่ token จริงของคุณ
```

3. Run: `Setup()`
4. Deploy เป็น Web App เวอร์ชันใหม่ โดยตั้ง Execute as: Me และ Who has access: Anyone
5. คัดลอก Web App URL ที่ลงท้าย `/exec`

## ขั้นตอน Vercel

1. อัปโหลดโฟลเดอร์นี้เข้า GitHub
2. Vercel > Add New Project > Import repo
3. ตั้ง Environment Variables:

```text
GAS_WEB_APP_URL=https://script.google.com/macros/s/xxxx/exec
GAS_API_SECRET=HAOS_1777448392812_5f154d07d5ca59a27854741941470dc3
```

4. Deploy

## CLI

Vercel CLI ใช้คำสั่ง `vercel` เพื่อ deploy จาก project root และ `vercel deploy --prod` เพื่อ production deployment ตามเอกสาร Vercel

```bash
npm i -g vercel
cd health-assistant-os-vercel
vercel link
vercel env add GAS_WEB_APP_URL
vercel env add GAS_API_SECRET
vercel deploy --prod
```

## URL สำคัญ

- หน้าโปรแกรม: `https://your-project.vercel.app`
- หน้าสาธารณะ: `https://your-project.vercel.app/public?publicId=APP-xxxx`

## หมายเหตุ

ชุดนี้ใช้ Vercel API route `/api/gas` เป็น proxy ไป Apps Script เพื่อลดปัญหา CORS และไม่เปิด secret ให้ browser เห็น
